<?php

require_once('../include/db_connect.php');

// connecting to database
$db = new db_connect();
$mysqli = $db->connect();

// json response array
$response = array();

// check for required fields
if (isset($_GET["interval"])) {
    // receiving the post params
    $interval = $_GET["interval"];

    $stmt = $mysqli->stmt_init();
    // get data from database
    switch ($interval) {
        case 'last':
            // get the last 10 data
            $query = "SELECT * FROM data_storage ORDER BY id DESC LIMIT 10;";
            $result = $mysqli->query($query);
            if ($result) {
                if ($result->num_rows) {
                // success node
                $response["success"] = TRUE;
                // data node
                $response["data"] = array();
                while ($row = $result->fetch_assoc()) {
                    // create node
                    $data = array();
                    $data["heartrate"] = $row["heartrate"];
                    $data["measured_at"] = $row["measured_at"];

                    // push single data into final response array
                    array_push($response["data"], $data);
                }
                // echoing JSON response
                echo json_encode($response);
                } else {
                    // data is not found
                    $response["success"] = FALSE;
                    $response["message"] = "Oops! data is not found.";

                    // echoing JSON response
                    echo json_encode($response);
                }
            } else {
                print("Ooop! Error quering MySQL.");
            }
            break;

        case 'day':
            $query = "SELECT * FROM data_storage WHERE measured_at BETWEEN SUBDATE(CURDATE(), INTERVAL 24 HOUR) AND NOW();";
            $result = $mysqli->query($query);
            if ($result) {
                if ($result->num_rows) {
                // success node
                $response["success"] = TRUE;
                // data node
                $response["data"] = array();
                while ($row = $result->fetch_assoc()) {
                    // create node
                    $data = array();
                    $data["heartrate"] = $row["heartrate"];
                    $data["measured_at"] = $row["measured_at"];

                    // push single data into final response array
                    array_push($response["data"], $data);
                }
                // echoing JSON response
                echo json_encode($response);
                } else {
                    // data is not found
                    $response["success"] = FALSE;
                    $response["message"] = "Oops! data is not found.";

                    // echoing JSON response
                    echo json_encode($response);
                }
            } else {
                print("Ooop! Error quering MySQL.");
            }
            break;

        case 'week':
            $query = "SELECT * FROM data_storage WHERE measured_at BETWEEN SUBDATE(CURDATE(), INTERVAL 1 WEEK) AND NOW();";
            $result = $mysqli->query($query);
            if ($result) {
                if ($result->num_rows) {
                // success node
                $response["success"] = TRUE;
                // data node
                $response["data"] = array();
                while ($row = $result->fetch_assoc()) {
                    // create node
                    $data = array();
                    $data["heartrate"] = $row["heartrate"];
                    $data["measured_at"] = $row["measured_at"];

                    // push single data into final response array
                    array_push($response["data"], $data);
                }
                // echoing JSON response
                echo json_encode($response);
                } else {
                    // data is not found
                    $response["success"] = FALSE;
                    $response["message"] = "Oops! data is not found.";

                    // echoing JSON response
                    echo json_encode($response);
                }
            } else {
                print("Ooop! Error quering MySQL.");
            }
            break;

        case 'month':
            $query = "SELECT * FROM data_storage WHERE measured_at BETWEEN SUBDATE(CURDATE(), INTERVAL 1 MONTH) AND NOW();";
            $result = $mysqli->query($query);
            if ($result) {
                if ($result->num_rows) {
                // success node
                $response["success"] = TRUE;
                // data node
                $response["data"] = array();
                while ($row = $result->fetch_assoc()) {
                    // create node
                    $data = array();
                    $data["heartrate"] = $row["heartrate"];
                    $data["measured_at"] = $row["measured_at"];

                    // push single data into final response array
                    array_push($response["data"], $data);
                }
                // echoing JSON response
                echo json_encode($response);
                } else {
                    // data is not found
                    $response["success"] = FALSE;
                    $response["message"] = "Oops! data is not found.";

                    // echoing JSON response
                    echo json_encode($response);
                }
            } else {
                print("Ooop! Error quering MySQL.");
            }
            break;

        default:
            // required field is missing
            $response["success"] = FALSE;
            $response["message"] = "Interval is not correct.";

            // echoing JSON response
            echo json_encode($response);
            break;
    }
} else {
  // required field is missing
  $response["success"] = FALSE;
  $response["message"] = "Required field(s) is missing";

  // echoing JSON response
  echo json_encode($response);
}

$mysqli->close();
