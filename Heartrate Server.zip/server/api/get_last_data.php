<?php

require_once('../include/db_functions.php');
$db = new db_functions();

// json response array
$response = array();

$returnData = $db->getLastData();

if ($returnData != false) {
    // user is found
    $response["success"] = TRUE;
    $response["heartrate"] = $returnData["heartrate"];
    $response["measured_at"] = $returnData["measured_at"];
    echo json_encode($response);
} else {
    // user is not found with the credentials
    $response["success"] = FALSE;
    $response["message"] = "Oops! data is not found.";
    echo json_encode($response);
}
