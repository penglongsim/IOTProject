/* Create table for user account */
CREATE TABLE users(
   id INT(11) PRIMARY key AUTO_INCREMENT,
   unique_id VARCHAR(23) NOT NULL UNIQUE,
   fullname VARCHAR(50) NOT NULL,
   email VARCHAR(100) NOT NULL UNIQUE,
   encrypted_password VARCHAR(80) NOT NULL,
   salt VARCHAR(10) NOT NULL,
   created_at datetime,
   updated_at datetime NULL
);
/* Create table for store admin account */
CREATE TABLE super_users(
   id INT(11) PRIMARY key AUTO_INCREMENT,
   fullname VARCHAR(50) NOT NULL,
   email VARCHAR(100) NOT NULL UNIQUE,
   encrypted_password VARCHAR(80) NOT NULL,
   salt VARCHAR(10) NOT NULL,
   created_at datetime,
   updated_at datetime NULL
);
/* Create table for storing data */
CREATE TABLE data_storage(
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    heartrate INT(4) NOT NULL,
    measured_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);
/* Create default admin user account */
INSERT INTO super_users(fullname, email, encrypted_password, salt, created_at) VALUES('Oem Daro', 'oemdaro@gmail.com', 'xjAgU3JJzzj+z4D088bHMErAi3YyNzcyYTZjMzll', '2772a6c39e', NOW());
