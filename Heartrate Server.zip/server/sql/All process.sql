-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2016 at 02:23 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_wsr_server`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_storage`
--

CREATE TABLE IF NOT EXISTS `data_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(100) NOT NULL,
  `water_content` int(4) NOT NULL,
  `temperature` float(5,2) NOT NULL,
  `isdry` tinyint(1) NOT NULL,
  `measured_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `data_storage`
--

INSERT INTO `data_storage` (`id`, `user_email`, `water_content`, `temperature`, `isdry`, `measured_at`, `updated_at`) VALUES
(1, 'oemdaro@gmail.com', 19, 28.50, 1, '2016-02-06 22:41:15', NULL),
(2, 'oemdaro@gmail.com', 20, 29.55, 1, '2016-02-06 22:41:15', NULL),
(3, 'oemdaro@gmail.com', 21, 30.00, 1, '2016-02-06 22:41:15', NULL),
(4, 'oemdaro@gmail.com', 22, 29.20, 1, '2016-02-06 22:41:15', NULL),
(5, 'oemdaro@gmail.com', 29, 31.00, 0, '2016-02-06 22:41:15', NULL),
(6, 'oemdaro@gmail.com', 32, 32.00, 0, '2016-02-06 22:41:15', NULL),
(7, 'oemdaro@gmail.com', 39, 32.00, 0, '2016-02-06 22:41:15', NULL),
(8, 'oemdaro@gmail.com', 41, 31.00, 0, '2016-02-06 22:41:15', NULL),
(9, 'oemdaro@gmail.com', 43, 31.50, 0, '2016-02-06 22:41:15', NULL),
(10, 'oemdaro@gmail.com', 43, 30.20, 0, '2016-02-06 22:41:15', NULL),
(11, 'oemdaro@gmail.com', 44, 30.50, 0, '2016-02-06 22:41:15', NULL),
(12, 'oemdaro@gmail.com', 20, 32.00, 1, '2016-02-06 22:41:15', NULL),
(13, 'oemdaro@gmail.com', 39, 32.00, 0, '2016-02-07 00:16:18', NULL),
(14, 'oemdaro@gmail.com', 20, 32.00, 1, '2016-02-20 14:20:41', NULL),
(15, 'oemdaro@gmail.com', 30, 30.50, 0, '2016-02-20 11:55:31', NULL),
(16, 'oemdaro@gmail.com', 23, 32.00, 1, '2016-02-20 11:58:30', NULL),
(17, 'oemdaro@gmail.com', 47, 31.50, 0, '2016-02-20 12:02:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `super_users`
--

CREATE TABLE IF NOT EXISTS `super_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `encrypted_password` varchar(80) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `super_users`
--

INSERT INTO `super_users` (`id`, `fullname`, `email`, `encrypted_password`, `salt`, `created_at`, `updated_at`) VALUES
(1, 'Oem Daro', 'oemdaro@gmail.com', 'xjAgU3JJzzj+z4D088bHMErAi3YyNzcyYTZjMzll', '2772a6c39e', '2015-12-23 06:01:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(23) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `encrypted_password` varchar(80) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`unique_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `unique_id`, `fullname`, `email`, `encrypted_password`, `salt`, `created_at`, `updated_at`) VALUES
(1, '567a3954b26095.38014219', 'Mey Chamroeun', 'chamroeun@gmail.com', '4sVhasLtYQHISRISYxba+Y9WXFYzOTUxYzEyMzI3', '3951c12327', '2015-12-23 06:04:04', NULL),
(2, '567dfdfedc22b8.40592158', 'Oem Daro', 'oemdaro@gmail.com', 'HSBE9MxyDGbCA41Qmzj4mjwWx20zMjM2NGQ0ZmY4', '32364d4ff8', '2015-12-26 02:39:58', NULL),
(3, '56b678786cbb84.79272253', 'Sothea', 'sothea@gmail.com', 'UxU9rk+T7iBoqLLUGILVS09dfCg2ZmI5MTEyNjk1', '6fb9112695', '2016-02-07 05:49:28', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
