/* a sample data for testing */
INSERT INTO data_storage(heartrate) VALUES(80);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(85);
INSERT INTO data_storage(heartrate) VALUES(70);
INSERT INTO data_storage(heartrate) VALUES(80);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(70);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
INSERT INTO data_storage(heartrate) VALUES(90);
