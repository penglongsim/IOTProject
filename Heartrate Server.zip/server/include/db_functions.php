<?php

/**
* DB function class
*/
class db_functions {
	private $conn;

    // constructor
	function __construct() {
		require_once('db_connect.php');

		// connecting to database
		$db = new db_connect();
		$this->conn = $db->connect();
	}

	// destructor
	function __destruct() {

	}

    /**
    *	Insert data of user to database
    */
    public function storeData($heartrate) {
        $stmt = $this->conn->prepare("INSERT INTO data_storage(heartrate) VALUES(?)");
        $stmt->bind_param("s", $heartrate);

        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            return false;
        }
    }

    public function getLastData() {
        $stmt = $this->conn->prepare("SELECT * FROM data_storage ORDER BY id DESC LIMIT 1");
        //$stmt->bind_param("s", $heartrate);

        if ($stmt->execute()) {
            $data = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $data;
        } else {
            return NULL;
        }
    }

}
